#!/usr/bin/env python

'''
Copyright (c) 2015, Mark Silliman
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
'''

# TurtleBot must have minimal.launch & amcl_demo.launch
# running prior to starting this script
# For simulation: launch gazebo world & amcl_demo prior to run this script

import rospy
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
from actionlib_msgs.msg import *
from geometry_msgs.msg import Pose, Point, Quaternion, Twist
from math import pow,atan2,sqrt
from ar_track_alvar_msgs.msg import AlvarMarkers

global navdonePublisher
global xcoord

class GoToPose():
    def __init__(self):

        self.goal_sent = False

	# What to do if shut down (e.g. Ctrl-C or failure)
	rospy.on_shutdown(self.shutdown)
	
	# Tell the action client that we want to spin a thread by default
	self.move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction)
	rospy.loginfo("Wait for the action server to come up")

	# Allow up to 5 seconds for the action server to come up
	self.move_base.wait_for_server(rospy.Duration(5))

    def goto(self, pos, quat):

        # Send a goal
        self.goal_sent = True
	goal = MoveBaseGoal()
	goal.target_pose.header.frame_id = 'map'
	goal.target_pose.header.stamp = rospy.Time.now()
        
        
        goal.target_pose.pose = Pose(Point(pos['x'], pos['y'], 0.000),
                                     Quaternion(quat['r1'], quat['r2'], quat['r3'], quat['r4']))
	# Start moving
        self.move_base.send_goal(goal)

	# Allow TurtleBot up to 60 seconds to complete task
	success = self.move_base.wait_for_result(rospy.Duration(60)) 

        state = self.move_base.get_state()
        result = False

        if success and state == GoalStatus.SUCCEEDED:
            # We made it!
            result = True
        else:
            self.move_base.cancel_goal()

        self.goal_sent = False

        return result

    def shutdown(self):
        if self.goal_sent:
            self.move_base.cancel_goal()
        rospy.loginfo("Stop")
        rospy.sleep(1)

def callback(msg):
    #rospy.loginfo("Pose is %d ",msg.markers)
    msg.markers
    for tag in (msg.markers):
    	#rospy.loginfo("Tag's Pose : %f, %f, %f",tag.pose.pose.position.x, tag.pose.pose.position.y, tag.pose.pose.position.z)
	point_in_baseframe = [[tag.pose.pose.position.x], [tag.pose.pose.position.y], [tag.pose.pose.position.z]]
	centre_pose = [6.53, 1.03, 0]
	tag_in_map = [centre_pose[0]+tag.pose.pose.position.x, centre_pose[1]+tag.pose.pose.position.y, centre_pose[2]+tag.pose.pose.position.z]		
	rospy.loginfo("Tag's pose in Map: [%f, %f, %f]",tag_in_map[0], tag_in_map[1], tag_in_map[2])	

if __name__ == '__main__':
    
    try:
        rospy.init_node('nav_test', anonymous=False)
        navigator = GoToPose()
        navdonePublisher = rospy.Publisher("/relay/nav_status", std_msgs.msg.String, queue_size = 10)
        i = 0
        tableA = False
        center = False
        rospy.Subscriber('ar_pose_marker', AlvarMarkers, callback)	

        

        while i < 2 :
            navigator = GoToPose()
            navdonePublisher = rospy.Publisher("/relay/nav_status", std_msgs.msg.String, queue_size = 10)
            if i == 0: # center
                position = {'x': 6.53, 'y' : 1.03} #{'x': 7.22, 'y' : 0.192}
                quaternion = {'r1' : 0.000, 'r2' : 0.000, 'r3' : -2.000, 'r4' : 1.000}
                center = True
                rospy.loginfo("Go to Center (%s, %s) pose", position['x'], position['y'])
            else:
                # table 1
                position = {'x': 5.73, 'y' : -0.16} # 5.77 0.121 5.73 -0.16
                quaternion = {'r1' : 0.000, 'r2' : 0.000, 'r3' : -2.000, 'r4' : 1.000}
                tableA = True
                rospy.loginfo("Go to Table A (%s, %s) pose", position['x'], position['y'])
            

            success = navigator.goto(position, quaternion)

	
            #if success and tableA:
                # publish "navdone" to /relay/nav_status
            #    navdonePublisher.publish(std_msgs.msg.String("navdone"))
            #if success and center:
            #    i = i + 1
            if not success and not tableA and not center:
                rospy.loginfo("The base failed to reach the desired pose")
            
	    i = i +1
            # Sleep to give the last log messages time to be sent
            rospy.sleep(1)
    except rospy.ROSInterruptException:
        rospy.loginfo("Ctrl-C caught. Quitting")

